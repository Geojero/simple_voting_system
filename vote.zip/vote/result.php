<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Providence College For Women</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 20px;
        }
        header {
            background-color: #333;
            color: white;
            padding: 15px;
            text-align: center;
        }
        h2 {
            background-color: #444;
            color: white;
            padding: 10px;
            text-align: center;
            text-align: center;
            color: #333;
        }
        div {
            background-color: #f0f000;
            font-size: 18px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            margin: 20px;
            width: 300px;
            margin-left: auto;
            margin-right: auto;
        }
        label {
            display: block;
            margin: 10px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #333;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #444;
            color: white;
        }
    </style>
</head>
<body>

    <header>
        <h1>Providence College For Women</h1>
        <p>(AUTONOMOUS) Institution Affiliated to Bharathiar University Re-accredited by NAAC with 'A'Grade <br>Coonoor, The Nilgiris</p>
    </header>
    <center>
        <div>
            <table>
                <tr>
                    <th>Candidate</th>
                    <th>Vote Count</th>
                </tr>
                <?php
                $candidates = array(
                    "person1", "person2", "person3", "person4", "person5",
                    "person6", "person7", "person8", "person9", "person10","person11","person12","person13","person14",
                );
                $names = array(
                    "Isabel", "Jemima", "Jerish", "Pushpa", "Jerry",
                    "Jeeva", "Oviya", "Sree", "Nazriya", "Susee","Raveena","Jessie","Hema","Sherin",
                );


                // Connect to the database
                $conn = new mysqli("localhost", "root", "", "vote_base");

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Fetch vote counts for each candidate
                foreach ($names as $index => $name) {
    $candidate = $candidates[$index];
    $query = "SELECT COUNT($candidate) AS count_$candidate FROM voting";
    $result = $conn->query($query);
    $row = $result->fetch_assoc();
    $count = $row["count_$candidate"];
    echo "<tr><td>$name</td><td>$count</td></tr>";
}

                // Close the database connection
                $conn->close();
                ?>
            </table>
        </div>

    </center>

    <footer>
        &copy; <?php echo date("Y"); ?> Providence College For Women. All rights reserved.
    </footer>

</body>
</html>
