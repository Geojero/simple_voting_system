
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="refresh" content="5;url=eg1.html">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Providence College For Women</title>
    <style>
         body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 20px;
        }
         header {
            background-color: #333;
            color: white;
            padding: 15px;
            text-align: center;
        }
     

        h2 {
              background-color: #444;
            color: white;
            padding: 10px;
            text-align: center;
            text-align: center;
            color: #333;
        }

        label {
            display: block;
            margin: 10px 0;
        }

        input[type="button"] {
            background-color: #808080; /* Neon Orange color */
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
        }

        input[type="button"]:hover {
            transform: scale(1.1);
            box-shadow: 0 0 10px 5px #FFA500; /* Glowing effect */
        }
    </style>
</head>
<body>

    <header>
        <h1>Providence College For Women</h1>
        <p>(AUTONOMOUS)

Institution Affiliated to Bharathiar University

Re-accredited by NAAC with 'A'Grade <br>Coonoor, The Nilgiris</p>
    
    </header>
    <center>
    <h1>Your Vote Saved Successfully......</h1>
<br><br>
    <button onclick="window.location.href='eg1.html'">Go to Previous Page</button>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <button onclick="window.location.href='result.php'">result</button>
    </center>
    <footer>
        &copy; <?php echo date("Y"); ?> Providence College For Women. All rights reserved.
    </footer>

</body>
</html>


<?php
$person1 = isset($_POST['person1']) ? $_POST['person1'] : null;
$person2 = isset($_POST['person2']) ? $_POST['person2'] : null;
$person3 = isset($_POST['person3']) ? $_POST['person3'] : null;
$person4 = isset($_POST['person4']) ? $_POST['person4'] : null;
$person5 = isset($_POST['person5']) ? $_POST['person5'] : null;
$person6 = isset($_POST['person6']) ? $_POST['person6'] : null;
$person7 = isset($_POST['person7']) ? $_POST['person7'] : null;
$person8 = isset($_POST['person8']) ? $_POST['person8'] : null;
$person9 = isset($_POST['person9']) ? $_POST['person9'] : null;
$person10 = isset($_POST['person10']) ? $_POST['person10'] : null;
$person11 = isset($_POST['person11']) ? $_POST['person11'] : null;
$person12 = isset($_POST['person12']) ? $_POST['person12'] : null;
$person13 = isset($_POST['person13']) ? $_POST['person13'] : null;
$person14 = isset($_POST['person14']) ? $_POST['person14'] : null;

$conn = new mysqli('localhost','root','','vote_base');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    $stmt = $conn->prepare("insert into voting(person1, person2, person3, person4, person5, person6, person7, person8, person9, person10, person11, person12, person13, person14) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssssssssss", $person1, $person2, $person3, $person4, $person5, $person6, $person7, $person8, $person9, $person10, $person11, $person12, $person13, $person14,);
    $stmt->execute();
    
    $stmt->close();
    $conn->close();
}
?>
